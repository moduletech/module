<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<?php require('templates/_head.php');?>
<body <?php body_class(); ?>>
