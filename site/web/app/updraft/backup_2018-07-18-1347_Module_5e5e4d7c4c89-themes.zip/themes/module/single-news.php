<?php header("Location: /news"); ?>
