<?php $profile_loaded = ( isset( $_GET['wpmdb-profile'] ) && '-1' !== $_GET['wpmdb-profile'] ) ? 'profile-loaded' : ''; ?>
<div class="import-file-status <?php echo $profile_loaded; ?>" style="display:none;"></div>
