<?php
$GLOBALS['wpmdb_meta']['wp-migrate-db-pro-cli']['version'] = '1.3.2';
$GLOBALS['wpmdb_meta']['wp-migrate-db-pro-cli']['required-php-version'] = '5.3.2';
