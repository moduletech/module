<div itemscope itemtype="http://schema.org/WebSite">
    <meta itemprop="url" content="http://mach1.com/"/>
    <form itemprop="potentialAction" itemscope itemtype="http://schema.org/SearchAction" method="get" id="searchform" class="searchform" action="<?php echo esc_url(home_url('/')); ?>">
        <meta itemprop="target" content="https://modulehousing.com/?s={s}"/> 
        <input type="text" class="form-control search-input" name="s" id="s" placeholder="Search Module Housing" itemprop="query-input">
    </form>
</div>